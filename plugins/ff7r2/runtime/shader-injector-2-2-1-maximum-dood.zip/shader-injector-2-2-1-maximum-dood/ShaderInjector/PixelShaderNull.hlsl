
float4 main() : SV_Target0
{
	return float4(1, 0, 0, 1); //red for error
}
