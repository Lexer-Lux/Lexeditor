
struct InputStruct 
{
	uint3 DispatchThreadID : SV_DispatchThreadID;
};

[numthreads(8, 8, 1)]
void main(in InputStruct IN)
{

}
