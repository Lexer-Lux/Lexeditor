
float4 main() : SV_Target0
{
	return float4(0, 0, 1, 1); //blue for marking
}
