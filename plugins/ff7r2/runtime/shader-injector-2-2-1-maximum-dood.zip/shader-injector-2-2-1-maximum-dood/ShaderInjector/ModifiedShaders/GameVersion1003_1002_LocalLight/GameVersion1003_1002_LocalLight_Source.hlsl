//DeferredLocalLightPS.hlsl
//Game Shader Version: 1.0.0.3 (and 1.0.0.2)

//[NO CONFIG]
//#define SHADER_VARIANT_LOCAL_LIGHT_IES

//NOTE: you'll find this in ShaderInjector/ModifiedShaders/Includes
#include "PixelShaderPass_LocalLight.hlsl"